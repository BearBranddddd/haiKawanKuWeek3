﻿namespace TH02
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb1 = new System.Windows.Forms.TextBox();
            this.tb2 = new System.Windows.Forms.TextBox();
            this.tb4 = new System.Windows.Forms.TextBox();
            this.tb3 = new System.Windows.Forms.TextBox();
            this.tb5 = new System.Windows.Forms.TextBox();
            this.butt = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel = new System.Windows.Forms.Panel();
            this.b1 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.b4 = new System.Windows.Forms.Button();
            this.b5 = new System.Windows.Forms.Button();
            this.b6 = new System.Windows.Forms.Button();
            this.b7 = new System.Windows.Forms.Button();
            this.b8 = new System.Windows.Forms.Button();
            this.b9 = new System.Windows.Forms.Button();
            this.b10 = new System.Windows.Forms.Button();
            this.b11 = new System.Windows.Forms.Button();
            this.b12 = new System.Windows.Forms.Button();
            this.b13 = new System.Windows.Forms.Button();
            this.b14 = new System.Windows.Forms.Button();
            this.b15 = new System.Windows.Forms.Button();
            this.b16 = new System.Windows.Forms.Button();
            this.b17 = new System.Windows.Forms.Button();
            this.b18 = new System.Windows.Forms.Button();
            this.b19 = new System.Windows.Forms.Button();
            this.b20 = new System.Windows.Forms.Button();
            this.b21 = new System.Windows.Forms.Button();
            this.b22 = new System.Windows.Forms.Button();
            this.b23 = new System.Windows.Forms.Button();
            this.b24 = new System.Windows.Forms.Button();
            this.b25 = new System.Windows.Forms.Button();
            this.b26 = new System.Windows.Forms.Button();
            this.kata1 = new System.Windows.Forms.Label();
            this.Test = new System.Windows.Forms.Label();
            this.keyboard = new System.Windows.Forms.Panel();
            this.panel.SuspendLayout();
            this.keyboard.SuspendLayout();
            this.SuspendLayout();
            // 
            // tb1
            // 
            this.tb1.Location = new System.Drawing.Point(202, 44);
            this.tb1.Name = "tb1";
            this.tb1.Size = new System.Drawing.Size(197, 31);
            this.tb1.TabIndex = 0;
            // 
            // tb2
            // 
            this.tb2.Location = new System.Drawing.Point(202, 121);
            this.tb2.Name = "tb2";
            this.tb2.Size = new System.Drawing.Size(197, 31);
            this.tb2.TabIndex = 1;
            // 
            // tb4
            // 
            this.tb4.Location = new System.Drawing.Point(202, 272);
            this.tb4.Name = "tb4";
            this.tb4.Size = new System.Drawing.Size(197, 31);
            this.tb4.TabIndex = 3;
            // 
            // tb3
            // 
            this.tb3.Location = new System.Drawing.Point(202, 194);
            this.tb3.Name = "tb3";
            this.tb3.Size = new System.Drawing.Size(197, 31);
            this.tb3.TabIndex = 2;
            // 
            // tb5
            // 
            this.tb5.Location = new System.Drawing.Point(202, 355);
            this.tb5.Name = "tb5";
            this.tb5.Size = new System.Drawing.Size(197, 31);
            this.tb5.TabIndex = 4;
            // 
            // butt
            // 
            this.butt.Location = new System.Drawing.Point(234, 428);
            this.butt.Name = "butt";
            this.butt.Size = new System.Drawing.Size(143, 57);
            this.butt.TabIndex = 5;
            this.butt.Text = "Play!";
            this.butt.UseVisualStyleBackColor = true;
            this.butt.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(103, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 25);
            this.label1.TabIndex = 6;
            this.label1.Text = "Word 1:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(103, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 25);
            this.label2.TabIndex = 7;
            this.label2.Text = "Word 2:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(103, 194);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 25);
            this.label3.TabIndex = 8;
            this.label3.Text = "Word 3:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(103, 272);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 25);
            this.label4.TabIndex = 9;
            this.label4.Text = "Word 4:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(103, 355);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 25);
            this.label5.TabIndex = 10;
            this.label5.Text = "Word 5:";
            // 
            // panel
            // 
            this.panel.Controls.Add(this.tb1);
            this.panel.Controls.Add(this.label5);
            this.panel.Controls.Add(this.tb2);
            this.panel.Controls.Add(this.label4);
            this.panel.Controls.Add(this.tb3);
            this.panel.Controls.Add(this.label3);
            this.panel.Controls.Add(this.tb4);
            this.panel.Controls.Add(this.label2);
            this.panel.Controls.Add(this.tb5);
            this.panel.Controls.Add(this.label1);
            this.panel.Controls.Add(this.butt);
            this.panel.Location = new System.Drawing.Point(86, 80);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(512, 593);
            this.panel.TabIndex = 11;
            this.panel.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_Paint);
            // 
            // b1
            // 
            this.b1.Location = new System.Drawing.Point(80, 260);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(117, 110);
            this.b1.TabIndex = 12;
            this.b1.Tag = "1";
            this.b1.Text = "Q";
            this.b1.UseVisualStyleBackColor = true;
            this.b1.Click += new System.EventHandler(this.b1_Click);
            // 
            // b2
            // 
            this.b2.Location = new System.Drawing.Point(203, 260);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(117, 110);
            this.b2.TabIndex = 13;
            this.b2.Tag = "2";
            this.b2.Text = "W";
            this.b2.UseVisualStyleBackColor = true;
            this.b2.Click += new System.EventHandler(this.b2_Click);
            // 
            // b3
            // 
            this.b3.Location = new System.Drawing.Point(326, 260);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(117, 110);
            this.b3.TabIndex = 14;
            this.b3.Tag = "3";
            this.b3.Text = "E";
            this.b3.UseVisualStyleBackColor = true;
            this.b3.Click += new System.EventHandler(this.b3_Click);
            // 
            // b4
            // 
            this.b4.Location = new System.Drawing.Point(449, 260);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(117, 110);
            this.b4.TabIndex = 15;
            this.b4.Text = "R";
            this.b4.UseVisualStyleBackColor = true;
            this.b4.Click += new System.EventHandler(this.b4_Click);
            // 
            // b5
            // 
            this.b5.Location = new System.Drawing.Point(572, 260);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(117, 110);
            this.b5.TabIndex = 16;
            this.b5.Tag = "5";
            this.b5.Text = "T";
            this.b5.UseVisualStyleBackColor = true;
            this.b5.Click += new System.EventHandler(this.b5_Click);
            // 
            // b6
            // 
            this.b6.Location = new System.Drawing.Point(695, 260);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(117, 110);
            this.b6.TabIndex = 17;
            this.b6.Text = "Y";
            this.b6.UseVisualStyleBackColor = true;
            this.b6.Click += new System.EventHandler(this.b6_Click);
            // 
            // b7
            // 
            this.b7.Location = new System.Drawing.Point(818, 260);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(117, 110);
            this.b7.TabIndex = 18;
            this.b7.Text = "U";
            this.b7.UseVisualStyleBackColor = true;
            this.b7.Click += new System.EventHandler(this.b7_Click);
            // 
            // b8
            // 
            this.b8.Location = new System.Drawing.Point(942, 260);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(117, 110);
            this.b8.TabIndex = 19;
            this.b8.Text = "I";
            this.b8.UseVisualStyleBackColor = true;
            this.b8.Click += new System.EventHandler(this.b8_Click);
            // 
            // b9
            // 
            this.b9.Location = new System.Drawing.Point(1065, 260);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(117, 110);
            this.b9.TabIndex = 20;
            this.b9.Text = "O";
            this.b9.UseVisualStyleBackColor = true;
            this.b9.Click += new System.EventHandler(this.b9_Click);
            // 
            // b10
            // 
            this.b10.Location = new System.Drawing.Point(1188, 260);
            this.b10.Name = "b10";
            this.b10.Size = new System.Drawing.Size(117, 110);
            this.b10.TabIndex = 21;
            this.b10.Text = "P";
            this.b10.UseVisualStyleBackColor = true;
            this.b10.Click += new System.EventHandler(this.b10_Click);
            // 
            // b11
            // 
            this.b11.Location = new System.Drawing.Point(114, 376);
            this.b11.Name = "b11";
            this.b11.Size = new System.Drawing.Size(117, 110);
            this.b11.TabIndex = 22;
            this.b11.Text = "A";
            this.b11.UseVisualStyleBackColor = true;
            this.b11.Click += new System.EventHandler(this.b11_Click);
            // 
            // b12
            // 
            this.b12.Location = new System.Drawing.Point(237, 376);
            this.b12.Name = "b12";
            this.b12.Size = new System.Drawing.Size(117, 110);
            this.b12.TabIndex = 23;
            this.b12.Text = "S";
            this.b12.UseVisualStyleBackColor = true;
            this.b12.Click += new System.EventHandler(this.b12_Click);
            // 
            // b13
            // 
            this.b13.Location = new System.Drawing.Point(360, 376);
            this.b13.Name = "b13";
            this.b13.Size = new System.Drawing.Size(117, 110);
            this.b13.TabIndex = 24;
            this.b13.Text = "D";
            this.b13.UseVisualStyleBackColor = true;
            this.b13.Click += new System.EventHandler(this.b13_Click);
            // 
            // b14
            // 
            this.b14.Location = new System.Drawing.Point(483, 376);
            this.b14.Name = "b14";
            this.b14.Size = new System.Drawing.Size(117, 110);
            this.b14.TabIndex = 25;
            this.b14.Text = "F";
            this.b14.UseVisualStyleBackColor = true;
            this.b14.Click += new System.EventHandler(this.b14_Click);
            // 
            // b15
            // 
            this.b15.Location = new System.Drawing.Point(606, 376);
            this.b15.Name = "b15";
            this.b15.Size = new System.Drawing.Size(117, 110);
            this.b15.TabIndex = 26;
            this.b15.Text = "G";
            this.b15.UseVisualStyleBackColor = true;
            this.b15.Click += new System.EventHandler(this.b15_Click);
            // 
            // b16
            // 
            this.b16.Location = new System.Drawing.Point(729, 376);
            this.b16.Name = "b16";
            this.b16.Size = new System.Drawing.Size(117, 110);
            this.b16.TabIndex = 27;
            this.b16.Text = "H";
            this.b16.UseVisualStyleBackColor = true;
            this.b16.Click += new System.EventHandler(this.b16_Click);
            // 
            // b17
            // 
            this.b17.Location = new System.Drawing.Point(852, 376);
            this.b17.Name = "b17";
            this.b17.Size = new System.Drawing.Size(117, 110);
            this.b17.TabIndex = 28;
            this.b17.Text = "J";
            this.b17.UseVisualStyleBackColor = true;
            this.b17.Click += new System.EventHandler(this.b17_Click);
            // 
            // b18
            // 
            this.b18.Location = new System.Drawing.Point(975, 376);
            this.b18.Name = "b18";
            this.b18.Size = new System.Drawing.Size(117, 110);
            this.b18.TabIndex = 29;
            this.b18.Text = "K";
            this.b18.UseVisualStyleBackColor = true;
            this.b18.Click += new System.EventHandler(this.b18_Click);
            // 
            // b19
            // 
            this.b19.Location = new System.Drawing.Point(1098, 376);
            this.b19.Name = "b19";
            this.b19.Size = new System.Drawing.Size(117, 110);
            this.b19.TabIndex = 30;
            this.b19.Text = "L";
            this.b19.UseVisualStyleBackColor = true;
            this.b19.Click += new System.EventHandler(this.b19_Click);
            // 
            // b20
            // 
            this.b20.Location = new System.Drawing.Point(161, 492);
            this.b20.Name = "b20";
            this.b20.Size = new System.Drawing.Size(117, 110);
            this.b20.TabIndex = 31;
            this.b20.Text = "Z";
            this.b20.UseVisualStyleBackColor = true;
            this.b20.Click += new System.EventHandler(this.b20_Click);
            // 
            // b21
            // 
            this.b21.Location = new System.Drawing.Point(284, 492);
            this.b21.Name = "b21";
            this.b21.Size = new System.Drawing.Size(117, 110);
            this.b21.TabIndex = 32;
            this.b21.Text = "X";
            this.b21.UseVisualStyleBackColor = true;
            this.b21.Click += new System.EventHandler(this.b21_Click);
            // 
            // b22
            // 
            this.b22.Location = new System.Drawing.Point(407, 492);
            this.b22.Name = "b22";
            this.b22.Size = new System.Drawing.Size(117, 110);
            this.b22.TabIndex = 33;
            this.b22.Text = "C";
            this.b22.UseVisualStyleBackColor = true;
            this.b22.Click += new System.EventHandler(this.b22_Click);
            // 
            // b23
            // 
            this.b23.Location = new System.Drawing.Point(530, 492);
            this.b23.Name = "b23";
            this.b23.Size = new System.Drawing.Size(117, 110);
            this.b23.TabIndex = 34;
            this.b23.Text = "V";
            this.b23.UseVisualStyleBackColor = true;
            this.b23.Click += new System.EventHandler(this.b23_Click);
            // 
            // b24
            // 
            this.b24.Location = new System.Drawing.Point(653, 492);
            this.b24.Name = "b24";
            this.b24.Size = new System.Drawing.Size(117, 110);
            this.b24.TabIndex = 35;
            this.b24.Text = "B";
            this.b24.UseVisualStyleBackColor = true;
            this.b24.Click += new System.EventHandler(this.b24_Click);
            // 
            // b25
            // 
            this.b25.Location = new System.Drawing.Point(776, 492);
            this.b25.Name = "b25";
            this.b25.Size = new System.Drawing.Size(117, 110);
            this.b25.TabIndex = 36;
            this.b25.Text = "N";
            this.b25.UseVisualStyleBackColor = true;
            this.b25.Click += new System.EventHandler(this.b25_Click);
            // 
            // b26
            // 
            this.b26.Location = new System.Drawing.Point(899, 492);
            this.b26.Name = "b26";
            this.b26.Size = new System.Drawing.Size(117, 110);
            this.b26.TabIndex = 37;
            this.b26.Text = "M";
            this.b26.UseVisualStyleBackColor = true;
            this.b26.Click += new System.EventHandler(this.b26_Click);
            // 
            // kata1
            // 
            this.kata1.AutoSize = true;
            this.kata1.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kata1.Location = new System.Drawing.Point(507, 103);
            this.kata1.Name = "kata1";
            this.kata1.Size = new System.Drawing.Size(322, 85);
            this.kata1.TabIndex = 38;
            this.kata1.Text = "_ _ _ _ _";
            // 
            // Test
            // 
            this.Test.AutoSize = true;
            this.Test.Location = new System.Drawing.Point(1132, 61);
            this.Test.Name = "Test";
            this.Test.Size = new System.Drawing.Size(143, 25);
            this.Test.TabIndex = 43;
            this.Test.Text = "HAHAHAHHA";
            // 
            // keyboard
            // 
            this.keyboard.Controls.Add(this.Test);
            this.keyboard.Controls.Add(this.kata1);
            this.keyboard.Controls.Add(this.b26);
            this.keyboard.Controls.Add(this.b25);
            this.keyboard.Controls.Add(this.b24);
            this.keyboard.Controls.Add(this.b23);
            this.keyboard.Controls.Add(this.b22);
            this.keyboard.Controls.Add(this.b21);
            this.keyboard.Controls.Add(this.b20);
            this.keyboard.Controls.Add(this.b19);
            this.keyboard.Controls.Add(this.b18);
            this.keyboard.Controls.Add(this.b17);
            this.keyboard.Controls.Add(this.b16);
            this.keyboard.Controls.Add(this.b15);
            this.keyboard.Controls.Add(this.b14);
            this.keyboard.Controls.Add(this.b13);
            this.keyboard.Controls.Add(this.b12);
            this.keyboard.Controls.Add(this.b11);
            this.keyboard.Controls.Add(this.b10);
            this.keyboard.Controls.Add(this.b9);
            this.keyboard.Controls.Add(this.b8);
            this.keyboard.Controls.Add(this.b7);
            this.keyboard.Controls.Add(this.b6);
            this.keyboard.Controls.Add(this.b5);
            this.keyboard.Controls.Add(this.b4);
            this.keyboard.Controls.Add(this.b3);
            this.keyboard.Controls.Add(this.b2);
            this.keyboard.Controls.Add(this.b1);
            this.keyboard.Location = new System.Drawing.Point(631, 80);
            this.keyboard.Name = "keyboard";
            this.keyboard.Size = new System.Drawing.Size(1361, 651);
            this.keyboard.TabIndex = 44;
            this.keyboard.Tag = "4";
            this.keyboard.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1571, 850);
            this.Controls.Add(this.panel);
            this.Controls.Add(this.keyboard);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel.ResumeLayout(false);
            this.panel.PerformLayout();
            this.keyboard.ResumeLayout(false);
            this.keyboard.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tb1;
        private System.Windows.Forms.TextBox tb2;
        private System.Windows.Forms.TextBox tb4;
        private System.Windows.Forms.TextBox tb3;
        private System.Windows.Forms.TextBox tb5;
        private System.Windows.Forms.Button butt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button b3;
        private System.Windows.Forms.Button b4;
        private System.Windows.Forms.Button b5;
        private System.Windows.Forms.Button b6;
        private System.Windows.Forms.Button b7;
        private System.Windows.Forms.Button b8;
        private System.Windows.Forms.Button b9;
        private System.Windows.Forms.Button b10;
        private System.Windows.Forms.Button b11;
        private System.Windows.Forms.Button b12;
        private System.Windows.Forms.Button b13;
        private System.Windows.Forms.Button b14;
        private System.Windows.Forms.Button b15;
        private System.Windows.Forms.Button b16;
        private System.Windows.Forms.Button b17;
        private System.Windows.Forms.Button b18;
        private System.Windows.Forms.Button b19;
        private System.Windows.Forms.Button b20;
        private System.Windows.Forms.Button b21;
        private System.Windows.Forms.Button b22;
        private System.Windows.Forms.Button b23;
        private System.Windows.Forms.Button b24;
        private System.Windows.Forms.Button b25;
        private System.Windows.Forms.Button b26;
        private System.Windows.Forms.Label kata1;
        private System.Windows.Forms.Label Test;
        private System.Windows.Forms.Panel keyboard;
    }
}

