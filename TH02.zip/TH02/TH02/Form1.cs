﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH02
{
    public partial class Form1 : Form
    {
        string kata;
        public Form1()
        {
            InitializeComponent();
        }
        public void haha (char aa)
        {
            for (int i = 0; i < 9; i++)
            {
                if (kata[i] == aa)
                {
                    kata1.Text = kata1.Text.Remove(i, 1);
                    kata1.Text = kata1.Text.Insert(i, aa.ToString());
                }
            }
            if (kata1.Text == kata)
            {
                MessageBox.Show("YOU WINNNNNN");
            }
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            List<string> list = new List<string>();
            

            int aa = Convert.ToInt32(tb1.Text.Length);
            int bb = Convert.ToInt32(tb2.Text.Length);
            int cc = Convert.ToInt32(tb3.Text.Length);
            int dd = Convert.ToInt32(tb4.Text.Length);
            int ee = Convert.ToInt32(tb5.Text.Length);

            list.Add(tb1.Text);
            list.Add(tb2.Text);
            list.Add(tb3.Text);
            list.Add(tb4.Text);
            list.Add(tb5.Text);
            int tes = 0;
            int tesangka = 0;
            string z = "1234567890";
            
            for (int i = 0;i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    if (list[i] == list[j])
                    {
                        tes++;
                        
                    }
                }
            }
            foreach (string r in list)
            {
                foreach (char b in z)
                {
                    for (int i = 0; i < r.Length; i++)
                    {
                        if (r[i] == b)
                        {
                            tesangka++;
                        }
                    }
                }
            }

            if (aa != 5 || bb != 5 || cc != 5 || dd != 5 || ee != 5)
            {
                MessageBox.Show("There's still an error");
                butt.Enabled = true;
            }
            else if (tesangka > 0)
            {
                MessageBox.Show("No usage of number");
            }
            else if (tes > 5)
            {
                MessageBox.Show("There's still an error");
            }
            else
            {
                MessageBox.Show("Let's Play");
                panel.Visible = false;
                keyboard.Visible = true;
                keyboard.Left = 0;
                Random random = new Random();
                int a = random.Next(0, 5);
                Test.Text = list[a].ToUpper();
                kata = list[a];
                kata = kata.ToUpper().Insert(1, " ").Insert(3, " ").Insert(5, " ").Insert(7, " ");
            }
        }        

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void b1_Click(object sender, EventArgs e)
        {
            haha('Q');
        }

        private void b2_Click(object sender, EventArgs e)
        {
            haha('W');
        }

        private void b3_Click(object sender, EventArgs e)
        {
            haha('E');
        }

        private void b4_Click(object sender, EventArgs e)
        {
            haha('R');
        }

        private void b5_Click(object sender, EventArgs e)
        {
            haha('T');
        }

        private void b6_Click(object sender, EventArgs e)
        {
            haha('Y');
        }

        private void b7_Click(object sender, EventArgs e)
        {
            haha('U');
        }

        private void b8_Click(object sender, EventArgs e)
        {
            haha('I');
        }

        private void b9_Click(object sender, EventArgs e)
        {
            haha('O');
        }

        private void b10_Click(object sender, EventArgs e)
        {
            haha('P');
        }

        private void b11_Click(object sender, EventArgs e)
        {
            haha('A');
        }

        private void b12_Click(object sender, EventArgs e)
        {
            haha('S');
        }

        private void b13_Click(object sender, EventArgs e)
        {
            haha('D');
        }

        private void b14_Click(object sender, EventArgs e)
        {
            haha('F');
        }

        private void b15_Click(object sender, EventArgs e)
        {
            haha('G');
        }

        private void b16_Click(object sender, EventArgs e)
        {
            haha('H');
        }

        private void b17_Click(object sender, EventArgs e)
        {
            haha('J');
        }

        private void b18_Click(object sender, EventArgs e)
        {
            haha('K');
        }

        private void b19_Click(object sender, EventArgs e)
        {
            haha('L');
        }

        private void b20_Click(object sender, EventArgs e)
        {
            haha('Z');
        }

        private void b21_Click(object sender, EventArgs e)
        {
            haha('X');
        }

        private void b22_Click(object sender, EventArgs e)
        {
            haha('C');
        }

        private void b23_Click(object sender, EventArgs e)
        {
            haha('V');
        }

        private void b24_Click(object sender, EventArgs e)
        {
            haha('B');
        }

        private void b25_Click(object sender, EventArgs e)
        {
            haha('N');
        }
        private void b26_Click(object sender, EventArgs e)
        {
            haha('M');
        }

        private void panel_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
